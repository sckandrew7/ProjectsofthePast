//
//  PersonalList.cpp
//  
//
//  Created by Andrews, Kenya on 10/28/15.
//
//

#include <iostream>
#include "PersonalList.h"
using namespace std;

PersonalList::PersonalList()
{
    head = nullptr;
}
void PersonalList::appendNode (string firstName, string lastName, long int phoneNum)
{
    PersonList *newNode;
    PersonList *nodePtr;
    
    newNode = new PersonList;
    newNode -> firstName = firstName;
    newNode -> lastName = lastName;
    newNode -> phoneNum = phoneNum;
    
    newNode -> next = nullptr;
    
    if(!head)
        head = newNode;
    else
    {
        nodePtr = head;
        while(nodePtr->next)
            nodePtr = nodePtr->next;
        
        nodePtr->next = newNode;
    }
}

void PersonalList::displayList() const{
    PersonList *nodePtr;
    
    nodePtr = head;
    while(nodePtr)
    {
        cout << nodePtr -> firstName << endl;
        cout << nodePtr ->lastName << endl;
        cout << nodePtr -> phoneNum << endl;
        
        nodePtr = nodePtr->next;
    }
}