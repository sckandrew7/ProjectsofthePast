//
//  PersonalList.h
//  
//
//  Created by Andrews, Kenya on 10/28/15.
//
//

#include <stdio.h>
#include <string>
#ifndef PERSONALLIST_H
#define PERSONALLIST_H
using namespace std;

class PersonalList
{
private:
    struct PersonList{
        string firstName;
        string lastName;
        long int phoneNum;
        
        struct PersonList *next;
    };
    
    PersonList *head;
    
public:
    PersonalList();
    
    //~PersonalList();
    
    void appendNode (string firstName, string lastName, long int phoneNum);
    void displayList() const;
    
};
#endif
