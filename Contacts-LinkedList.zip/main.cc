//
//  main.cc
//  
//
//  Created by Andrews, Kenya on 10/28/15.
//
//
#include "PersonalList.h"
#include <iostream>
using namespace std;

int main()
{
PersonalList firstList;

firstList.appendNode("Bob", "Sam", 12345267898);
firstList.appendNode("Paul", "Jamie" , 4781238529);
firstList.appendNode("Chrus", "Paul", 9874120230);
firstList.appendNode("Lang", "Jane", 9587411234);
firstList.appendNode("Busy","Body", 9874561230);
firstList.appendNode("Tucker", "Miles", 4783945907);

    PersonalList secondList;
    secondList.appendNode("Kierra", "Loius", 2316547890);
    secondList.appendNode("Lanxton", "Node", 6541230258);
    secondList.appendNode("Mixy", "Center", 9638527410);
    secondList.appendNode("Why", "GotTO", 4042705120);
    secondList.appendNode("Be", "Cool", 4705895789);
    secondList.appendNode("GiveMe", "APluses", 3210257406);

firstList.displayList();
    secondList.displayList();

return 0;
}